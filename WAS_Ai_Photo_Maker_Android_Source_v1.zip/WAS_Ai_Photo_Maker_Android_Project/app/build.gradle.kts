plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.was.aimaker"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.was.aimaker"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("com.google.mlkit:segmentation-selfie:16.0.0-beta6")
}
