package com.was.aimaker

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import com.google.mlkit.vision.common.InputImage
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private var original: Bitmap? = null
    private var result: Bitmap? = null
    private var bgColor = Color.WHITE
    private var photoW = 35
    private var photoH = 45
    private val segmenter by lazy {
        Segmentation.getClient(
            SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build()
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(11, 16, 32))
        }
        val title = TextView(this).apply {
            text = "W A S Ai Photo Maker"
            textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 14); setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)
        val sub = TextView(this).apply {
            text = "AI Passport • Visa • ID Photo Studio"
            textSize = 13f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(sub)
        preview = ImageView(this).apply {
            setBackgroundColor(Color.rgb(30, 42, 65))
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Passport photo preview"
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, 16, 0, 12) })
        status = TextView(this).apply {
            text = "Gallery se photo select karein ya camera use karein."
            setTextColor(Color.LTGRAY); textSize = 13f
        }
        root.addView(status)
        addButton(root, "📁 Gallery / Files se Photo", ::pickImage)
        addButton(root, "📷 Camera se Photo", ::takePhoto)
        val standards = Spinner(this)
        val options = listOf("Pakistan 35×45 mm", "UK 35×45 mm", "EU 35×45 mm", "USA 51×51 mm", "UAE 35×45 mm")
        standards.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        standards.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (pos == 3) { photoW = 51; photoH = 51 } else { photoW = 35; photoH = 45 }
            }
        }
        root.addView(standards)
        val colors = Spinner(this)
        val colorNames = listOf("White", "Light Blue", "Blue", "Red", "Grey", "Black")
        colors.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, colorNames)
        colors.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) {
                bgColor = listOf(Color.WHITE, Color.rgb(220,235,255), Color.rgb(40,117,215), Color.RED, Color.GRAY, Color.BLACK)[pos]
            }
        }
        root.addView(colors)
        addButton(root, "✨ AI Background Remove & Change", ::removeBackground)
        addButton(root, "✦ Photo Enhance", ::enhance)
        addButton(root, "🖨 4×6 Print Sheet", { exportSheet(4f, 6f) })
        addButton(root, "🖨 A4 Print Sheet", { exportSheet(8.27f, 11.69f) })
        addButton(root, "⬇ Save Passport Photo", ::savePhoto)
        addButton(root, "⬇ Save Print Sheet", ::saveSheet)
        val credit = TextView(this).apply {
            text = "Developed by Waseem Akram Suleman • Cell 0306-3354092"
            textSize = 11f; setTextColor(Color.rgb(77,224,193)); gravity = Gravity.CENTER
            setPadding(0, 12, 0, 0)
        }
        root.addView(credit)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) })
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
        }
        startActivityForResult(i, 10)
    }

    private fun takePhoto() {
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (i.resolveActivity(packageManager) != null) startActivityForResult(i, 11)
        else status.text = "Is phone par camera app available nahi."
    }

    @Deprecated("Legacy callback kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return
        try {
            val bmp = if (requestCode == 11) {
                (data.extras?.get("data") as? Bitmap)
            } else {
                data.data?.let { uri ->
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }
            }
            if (bmp == null) { status.text = "Photo read nahi ho saki."; return }
            original = normalize(bmp)
            result = original
            preview.setImageBitmap(result)
            status.text = "Photo load ho gayi. Background ya Enhance select karein."
        } catch (e: Exception) { status.text = "Image error: ${e.message}" }
    }

    private fun normalize(src: Bitmap): Bitmap {
        val maxSide = 2200
        val scale = min(1f, maxSide.toFloat() / max(src.width, src.height))
        return Bitmap.createScaledBitmap(src, (src.width*scale).roundToInt(), (src.height*scale).roundToInt(), true)
    }

    private fun removeBackground() {
        val bmp = original ?: run { status.text = "Pehle photo select karein."; return }
        status.text = "On-device AI background process ho raha hai…"
        val image = InputImage.fromBitmap(bmp, 0)
        segmenter.process(image)
            .addOnSuccessListener { mask ->
                try {
                    val maskBitmap = run {
                        val w = mask.width
                        val h = mask.height
                        val confidenceBuffer = mask.buffer.order(ByteOrder.nativeOrder()).asFloatBuffer()
                        confidenceBuffer.rewind()
                        val pixels = IntArray(w * h)
                        for (i in pixels.indices) {
                            val confidence = confidenceBuffer.getFloat().coerceIn(0f, 1f)
                            val alpha = (confidence * 255f).roundToInt()
                            pixels[i] = Color.argb(alpha, 255, 255, 255)
                        }
                        Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
                    }
                    val out = Bitmap.createBitmap(bmp.width,bmp.height,Bitmap.Config.ARGB_8888)
                    val c = Canvas(out)
                    c.drawColor(bgColor)
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    val scaledMask = Bitmap.createScaledBitmap(maskBitmap,bmp.width,bmp.height,true)
                    val layer = Bitmap.createBitmap(bmp.width,bmp.height,Bitmap.Config.ARGB_8888)
                    Canvas(layer).drawBitmap(bmp,0f,0f,null)
                    val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
                    Canvas(layer).drawBitmap(scaledMask,0f,0f,maskPaint)
                    c.drawBitmap(layer,0f,0f,paint)
                    result = out; preview.setImageBitmap(out)
                    status.text = "AI background remove complete. Background colour apply ho gaya."
                } catch (e: Exception) { status.text = "Mask process error: ${e.message}" }
            }
            .addOnFailureListener { status.text = "AI segmentation fail: ${it.message}" }
    }

    private fun enhance() {
        val bmp = result ?: original ?: run { status.text = "Pehle photo select karein."; return }
        val out = Bitmap.createBitmap(bmp.width,bmp.height,Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                1.08f,0f,0f,0f,2f, 0f,1.08f,0f,0f,2f, 0f,0f,1.08f,0f,2f, 0f,0f,0f,1f,0f
            )))
        }
        c.drawBitmap(bmp,0f,0f,p)
        result = out; preview.setImageBitmap(out)
        status.text = "Enhance applied: brightness, contrast aur colour adjustment. (AI face retouch nahi)"
    }

    private fun passportBitmap(): Bitmap? {
        val src = result ?: original ?: return null
        val ratio = photoW.toFloat()/photoH
        val cropW: Int; val cropH: Int
        if (src.width.toFloat()/src.height > ratio) {
            cropH = src.height; cropW = (cropH*ratio).roundToInt()
        } else { cropW = src.width; cropH = (cropW/ratio).roundToInt() }
        val x = (src.width-cropW)/2; val y = (src.height-cropH)/2
        return Bitmap.createBitmap(src,x,y,cropW,cropH)
    }

    private fun makeSheet(pageW: Float, pageH: Float): Bitmap? {
        val photo = passportBitmap() ?: return null
        val dpi = 150f
        val w = (pageW*dpi).roundToInt(); val h = (pageH*dpi).roundToInt()
        val sheet = Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
        val c = Canvas(sheet); c.drawColor(Color.WHITE)
        val pw = (photoW/25.4f*dpi).roundToInt(); val ph = (photoH/25.4f*dpi).roundToInt()
        val gap = (2f/25.4f*dpi).roundToInt()
        val cols = max(1,(w-gap)/(pw+gap)); val rows = max(1,(h-gap)/(ph+gap))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        for (r in 0 until rows) for (col in 0 until cols) {
            val left = gap + col*(pw+gap); val top = gap + r*(ph+gap)
            if (left+pw <= w && top+ph <= h) c.drawBitmap(photo,null,Rect(left,top,left+pw,top+ph),paint)
        }
        return sheet
    }

    private var lastSheet: Bitmap? = null
    private fun exportSheet(w: Float, h: Float) {
        lastSheet = makeSheet(w,h)
        if (lastSheet == null) { status.text = "Pehle photo select karein."; return }
        preview.setImageBitmap(lastSheet)
        status.text = "Print sheet preview ready. Save Print Sheet dabayein."
    }
    private fun savePhoto() {
        val bmp = passportBitmap() ?: run { status.text = "Pehle photo select karein."; return }
        saveBitmap(bmp,"WAS_Passport_${System.currentTimeMillis()}.jpg")
    }
    private fun saveSheet() {
        val bmp = lastSheet ?: run { status.text = "Pehle 4×6 ya A4 print sheet banayein."; return }
        saveBitmap(bmp,"WAS_Print_Sheet_${System.currentTimeMillis()}.jpg")
    }
    private fun saveBitmap(bmp: Bitmap, name: String) {
        try {
            val dir = File(getExternalFilesDir(null),"WAS_Photo_Maker").apply { mkdirs() }
            val f = File(dir,name)
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG,95,it) }
            status.text = "Saved: Android/data/com.was.aimaker/files/WAS_Photo_Maker/$name"
        } catch (e: Exception) { status.text = "Save error: ${e.message}" }
    }

    override fun onDestroy() { super.onDestroy(); segmenter.close() }
}
