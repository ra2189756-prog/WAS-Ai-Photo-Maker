W A S Ai Photo Maker — Android source project

Build:
1. Open this project in Android Studio.
2. Use JDK 17 and Gradle 8.9 (AGP 8.7.3).
3. Build > Build APK(s), or run: gradle assembleDebug
4. APK output: app/build/outputs/apk/debug/app-debug.apk

GitHub:
Push the project files/folders to the repository root (not as a ZIP inside the repository).
The included .github/workflows/android.yml builds the debug APK and uploads it as an Actions artifact.

Features in this starter:
- Gallery/file picker
- Camera intent (camera apps may return a thumbnail, not full-resolution)
- On-device ML Kit selfie segmentation for background replacement
- Preset passport dimensions
- Basic brightness/contrast adjustment (not AI face retouch)
- 4x6 and A4 JPEG print sheets
- Save JPEG output

Important:
- This is source code, not a prebuilt APK.
- The project has been statically reviewed and patched for the previously reported Java/Kotlin JVM target mismatch and ML Kit mask API usage.
- It has NOT been built with Android SDK or tested on a physical phone in this environment. A successful GitHub Actions run is still required before calling the APK build verified.
- ML Kit may need internet/Google Play services to obtain its model initially.
- Passport photo dimensions and layouts are provided as presets; check official country requirements before submitting a photo.
