W A S Ai Photo Maker — Android project

IMPORTANT STATUS:
Yeh Android Studio / GitHub Actions ke liye source project hai, APK nahi.
Is environment mein Android SDK/emulator aur real Android phone available nahi,
is liye APK build ya full device test yahan perform nahi hua. Isay tested APK na samjhein.

Features in this starter:
- Gallery / Files image picker (Android document picker)
- Camera launch (camera app)
- On-device ML Kit selfie segmentation dependency
- Background color selector
- Passport presets: Pakistan/UK/EU/UAE 35x45 mm, USA 51x51 mm
- Basic brightness/colour enhancement
- 4x6 and A4 print sheet generation
- JPG save
- Developer credit

Limitations / honest notes:
- Camera intent may return a small thumbnail depending on the camera app.
- ML Kit segmentation is a free on-device person segmentation model, but it is not
  a guaranteed studio-quality hair-edge cutout and can struggle with non-selfie scenes.
- The current enhancement is basic image adjustment, not generative AI face restoration.
- Passport crop is center crop, not official face-position compliance validation.
- Sheet output is 150 DPI JPEG; no PDF export in this starter.
- Pakistan passport dimensions should be checked against current official submission rules.
- The GitHub workflow is included to build an APK remotely, but it has not been run here.

Mobile-only build path:
1. Sign in to GitHub in your mobile browser and create a new empty repository.
2. Upload all files/folders from this ZIP to the repository (keep folder structure).
3. Open Actions tab, enable Actions if prompted.
4. Run "Build Android APK" workflow.
5. When it completes, open its run and download artifact "WAS-Ai-Photo-Maker-debug-apk".
6. Extract the APK from the downloaded artifact ZIP and install it.
7. Test on your own Android phone. Allow installation from that browser/file manager only if you trust this project.

No paid Cutout.pro API, no API key and no subscription are used.
The first AI segmentation model may require internet once to download/cache, depending on device/model delivery.
Developer: Waseem Akram Suleman | Cell: 0306-3354092
