W A S Ai Photo Maker — Corrected Android Source v4

IMPORTANT:
- Yeh Android source project hai, APK file nahi.
- Main is environment mein Android SDK/emulator ke baghair APK build ya phone par full test nahi kar sakta.
- Is ZIP mein pichle compile errors ke liye corrected Kotlin code aur simple GitHub Actions workflow hai.
- Isay tab tak tested/error-free APK na samjhein jab tak GitHub Actions build green na ho aur phone par test na ho.

Corrections:
1. ML Kit ke sahi SelfieSegmenterOptions API ka istemal.
2. Segmentation mask ko documented ByteBuffer.getFloat() tareeqe se read karna.
3. 4x6 sheet ke inch arguments ko Float (4f, 6f) banana.
4. Segmenter ko sirf tab close karna jab woh initialize hua ho.
5. Workflow ab ZIP extract karne ki koshish nahi karta; project root se direct build karta hai.

Features in this starter:
- Gallery / Files image picker
- Camera launch (camera app thumbnail result)
- On-device ML Kit selfie segmentation
- Background colour choices
- Pakistan/UK/EU/UAE 35x45 mm and USA 51x51 mm presets
- Basic brightness/colour enhancement
- 4x6 and A4 print sheet as JPEG
- Developer credit

Known limitations:
- Camera intent may return a small thumbnail, not the full-resolution original.
- ML Kit selfie segmentation is not guaranteed studio-quality and can struggle with hair edges or difficult backgrounds.
- Enhancement is basic colour/brightness adjustment, not AI face restoration.
- Crop is center crop; no official biometric face-position compliance check.
- Export is JPEG at 150 DPI; no PDF export.
- Saved images are in the app-specific Android/data/com.was.aimaker/files/WAS_Photo_Maker folder.
- No Cutout.pro API, paid API key, or subscription is used.

GitHub upload:
Upload the CONTENTS of this ZIP into the ROOT of a new/clean GitHub repository.
Do not upload the outer folder as an extra nested directory.
Then open Actions. The workflow should start after push, or use "Run workflow".
A successful run creates artifact: WAS-Ai-Photo-Maker-debug-apk-v4.
Download that artifact ZIP and extract app-debug.apk.

Developer: Waseem Akram Suleman
Cell: 0306-3354092
