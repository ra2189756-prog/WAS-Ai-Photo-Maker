package com.was.aimaker

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.net.Uri
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.Segmenter
import com.google.mlkit.vision.segmentation.SelfieSegmenterOptions
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var preview: ImageView
    private lateinit var status: TextView

    private var original: Bitmap? = null
    private var result: Bitmap? = null
    private var lastSheet: Bitmap? = null
    private var bgColor: Int = Color.WHITE
    private var photoWmm: Int = 35
    private var photoHmm: Int = 45

    private val segmenterDelegate = lazy<Segmenter> {
        val options = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
        Segmentation.getClient(options)
    }
    private val segmenter: Segmenter by segmenterDelegate

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(11, 16, 32))
        }

        val title = TextView(this).apply {
            text = "W A S Ai Photo Maker"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "AI Passport • Visa • ID Photo Studio"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle)

        preview = ImageView(this).apply {
            setBackgroundColor(Color.rgb(30, 42, 65))
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Passport photo preview"
        }
        root.addView(
            preview,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(280)
            ).apply { setMargins(0, dp(14), 0, dp(12)) }
        )

        status = TextView(this).apply {
            text = "Gallery se photo select karein ya camera use karein."
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, 4, 0, 8)
        }
        root.addView(status)

        addButton(root, "Gallery / Files se Photo", ::pickImage)
        addButton(root, "Camera se Photo", ::takePhoto)

        val standards = Spinner(this)
        val standardNames = listOf(
            "Pakistan 35 x 45 mm",
            "UK 35 x 45 mm",
            "EU 35 x 45 mm",
            "USA 51 x 51 mm",
            "UAE 35 x 45 mm"
        )
        standards.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            standardNames
        )
        standards.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                if (position == 3) {
                    photoWmm = 51
                    photoHmm = 51
                } else {
                    photoWmm = 35
                    photoHmm = 45
                }
            }
        }
        root.addView(standards)

        val colors = Spinner(this)
        val colorNames = listOf("White", "Light Blue", "Blue", "Red", "Grey", "Black")
        colors.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            colorNames
        )
        colors.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                bgColor = listOf(
                    Color.WHITE,
                    Color.rgb(220, 235, 255),
                    Color.rgb(40, 117, 215),
                    Color.RED,
                    Color.GRAY,
                    Color.BLACK
                )[position]
            }
        }
        root.addView(colors)

        addButton(root, "AI Background Remove & Change", ::removeBackground)
        addButton(root, "Photo Enhance", ::enhance)
        addButton(root, "4 x 6 Print Sheet", { exportSheet(4f, 6f) })
        addButton(root, "A4 Print Sheet", { exportSheet(8.27f, 11.69f) })
        addButton(root, "Save Passport Photo", ::savePhoto)
        addButton(root, "Save Print Sheet", ::saveSheet)

        val credit = TextView(this).apply {
            text = "Developed by Waseem Akram Suleman • Cell 0306-3354092"
            textSize = 11f
            setTextColor(Color.rgb(77, 224, 193))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 0)
        }
        root.addView(credit)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }
        parent.addView(
            button,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dp(4), 0, dp(4)) }
        )
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, REQUEST_GALLERY)
    }

    private fun takePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) {
            startActivityForResult(intent, REQUEST_CAMERA)
        } else {
            status.text = "Is phone par camera app available nahi."
        }
    }

    @Deprecated("Legacy callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return

        try {
            val bitmap = if (requestCode == REQUEST_CAMERA) {
                data.extras?.get("data") as? Bitmap
            } else if (requestCode == REQUEST_GALLERY) {
                data.data?.let { uri: Uri ->
                    contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it)
                    }
                }
            } else {
                null
            }

            if (bitmap == null) {
                status.text = "Photo read nahi ho saki."
                return
            }

            original = normalize(bitmap)
            result = original
            lastSheet = null
            preview.setImageBitmap(result)
            status.text = "Photo load ho gayi. Background ya Enhance select karein."
        } catch (exception: Exception) {
            status.text = "Image error: ${exception.message}"
        }
    }

    private fun normalize(source: Bitmap): Bitmap {
        val maxSide = 2200
        val scale = min(1f, maxSide.toFloat() / max(source.width, source.height))
        val newWidth = (source.width * scale).roundToInt().coerceAtLeast(1)
        val newHeight = (source.height * scale).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, newWidth, newHeight, true)
    }

    private fun removeBackground() {
        val bitmap = original
        if (bitmap == null) {
            status.text = "Pehle photo select karein."
            return
        }

        status.text = "On-device AI background process ho raha hai..."
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        segmenter.process(inputImage)
            .addOnSuccessListener { mask ->
                try {
                    val maskWidth = mask.width
                    val maskHeight = mask.height
                    val maskBuffer = mask.buffer.duplicate().order(ByteOrder.nativeOrder())
                    val maskPixels = IntArray(maskWidth * maskHeight)

                    for (index in maskPixels.indices) {
                        val confidence = maskBuffer.float.coerceIn(0f, 1f)
                        val alpha = (confidence * 255f).roundToInt()
                        maskPixels[index] = Color.argb(alpha, 255, 255, 255)
                    }

                    val maskBitmap = Bitmap.createBitmap(
                        maskPixels,
                        maskWidth,
                        maskHeight,
                        Bitmap.Config.ARGB_8888
                    )
                    val scaledMask = Bitmap.createScaledBitmap(
                        maskBitmap,
                        bitmap.width,
                        bitmap.height,
                        true
                    )

                    val foreground = Bitmap.createBitmap(
                        bitmap.width,
                        bitmap.height,
                        Bitmap.Config.ARGB_8888
                    )
                    Canvas(foreground).drawBitmap(bitmap, 0f, 0f, null)

                    val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
                    }
                    Canvas(foreground).drawBitmap(scaledMask, 0f, 0f, maskPaint)
                    maskPaint.xfermode = null

                    val output = Bitmap.createBitmap(
                        bitmap.width,
                        bitmap.height,
                        Bitmap.Config.ARGB_8888
                    )
                    val canvas = Canvas(output)
                    canvas.drawColor(bgColor)
                    canvas.drawBitmap(
                        foreground,
                        0f,
                        0f,
                        Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    )

                    result = output
                    lastSheet = null
                    preview.setImageBitmap(output)
                    status.text = "Background remove ho gaya. Aap background colour badal kar dobara apply kar sakte hain."
                } catch (exception: Exception) {
                    status.text = "Mask process error: ${exception.message}"
                }
            }
            .addOnFailureListener { exception ->
                status.text = "AI segmentation fail: ${exception.message}"
            }
    }

    private fun enhance() {
        val bitmap = result ?: original
        if (bitmap == null) {
            status.text = "Pehle photo select karein."
            return
        }

        val output = Bitmap.createBitmap(
            bitmap.width,
            bitmap.height,
            Bitmap.Config.ARGB_8888
        )
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = android.graphics.ColorMatrixColorFilter(
                android.graphics.ColorMatrix(
                    floatArrayOf(
                        1.08f, 0f, 0f, 0f, 2f,
                        0f, 1.08f, 0f, 0f, 2f,
                        0f, 0f, 1.08f, 0f, 2f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        Canvas(output).drawBitmap(bitmap, 0f, 0f, paint)
        result = output
        lastSheet = null
        preview.setImageBitmap(output)
        status.text = "Basic brightness aur colour enhancement apply ho gayi."
    }

    private fun passportBitmap(): Bitmap? {
        val source = result ?: original ?: return null
        val targetRatio = photoWmm.toFloat() / photoHmm.toFloat()

        val cropWidth: Int
        val cropHeight: Int
        if (source.width.toFloat() / source.height > targetRatio) {
            cropHeight = source.height
            cropWidth = (cropHeight * targetRatio).roundToInt()
        } else {
            cropWidth = source.width
            cropHeight = (cropWidth / targetRatio).roundToInt()
        }

        val x = ((source.width - cropWidth) / 2).coerceAtLeast(0)
        val y = ((source.height - cropHeight) / 2).coerceAtLeast(0)
        return Bitmap.createBitmap(source, x, y, cropWidth, cropHeight)
    }

    private fun makeSheet(pageWidthInches: Float, pageHeightInches: Float): Bitmap? {
        val photo = passportBitmap() ?: return null
        val dpi = 150f
        val pageWidth = (pageWidthInches * dpi).roundToInt()
        val pageHeight = (pageHeightInches * dpi).roundToInt()

        val sheet = Bitmap.createBitmap(
            pageWidth,
            pageHeight,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(sheet)
        canvas.drawColor(Color.WHITE)

        val photoWidthPx = (photoWmm / 25.4f * dpi).roundToInt()
        val photoHeightPx = (photoHmm / 25.4f * dpi).roundToInt()
        val gap = (2f / 25.4f * dpi).roundToInt()

        val columns = max(1, (pageWidth - gap) / (photoWidthPx + gap))
        val rows = max(1, (pageHeight - gap) / (photoHeightPx + gap))
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        for (row in 0 until rows) {
            for (column in 0 until columns) {
                val left = gap + column * (photoWidthPx + gap)
                val top = gap + row * (photoHeightPx + gap)
                if (left + photoWidthPx <= pageWidth &&
                    top + photoHeightPx <= pageHeight
                ) {
                    canvas.drawBitmap(
                        photo,
                        null,
                        Rect(
                            left,
                            top,
                            left + photoWidthPx,
                            top + photoHeightPx
                        ),
                        paint
                    )
                }
            }
        }
        return sheet
    }

    private fun exportSheet(pageWidth: Float, pageHeight: Float) {
        val sheet = makeSheet(pageWidth, pageHeight)
        if (sheet == null) {
            status.text = "Pehle photo select karein."
            return
        }
        lastSheet = sheet
        preview.setImageBitmap(sheet)
        status.text = "Print sheet preview ready. Save Print Sheet dabayein."
    }

    private fun savePhoto() {
        val bitmap = passportBitmap()
        if (bitmap == null) {
            status.text = "Pehle photo select karein."
            return
        }
        saveBitmap(bitmap, "WAS_Passport_${System.currentTimeMillis()}.jpg")
    }

    private fun saveSheet() {
        val bitmap = lastSheet
        if (bitmap == null) {
            status.text = "Pehle 4 x 6 ya A4 print sheet banayein."
            return
        }
        saveBitmap(bitmap, "WAS_Print_Sheet_${System.currentTimeMillis()}.jpg")
    }

    private fun saveBitmap(bitmap: Bitmap, fileName: String) {
        try {
            val directory = File(
                getExternalFilesDir(null),
                "WAS_Photo_Maker"
            )
            if (!directory.exists() && !directory.mkdirs()) {
                status.text = "Save folder create nahi ho saka."
                return
            }

            val outputFile = File(directory, fileName)
            FileOutputStream(outputFile).use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            status.text = "Saved in app folder: Android/data/com.was.aimaker/files/WAS_Photo_Maker"
        } catch (exception: Exception) {
            status.text = "Save error: ${exception.message}"
        }
    }

    override fun onDestroy() {
        if (segmenterDelegate.isInitialized()) {
            segmenter.close()
        }
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_GALLERY = 10
        private const val REQUEST_CAMERA = 11
    }
}
